<?php
	echo "<div id=\"header\"><h1><b>Computer Engineering Technology - Computing Science</b><br>
        CST8238 Web Programming</b></h1></div>";
?>