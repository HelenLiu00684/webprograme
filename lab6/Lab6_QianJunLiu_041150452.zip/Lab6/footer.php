<?php



echo "<div id=\"footer\">
            <h4>
                041150452  <br>
                liu00684@algonquinlive.com  </h4>
         </div>";
?>

