<?php
	echo "<div id=\"content\">";
    echo "<a href='ChessBoard.php'>ChessBoard</a><br/>";
    echo "<a href='Prime.php'>Prime</a><br/>";
    echo "<a href='Pattern.php'>Pattern</a><br/>";
	echo "</div>";
?>