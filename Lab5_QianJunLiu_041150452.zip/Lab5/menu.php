<?php			
    echo "<div id=\"menu\">
			<ul>
				<h2>
					<li><a href=\"index.php\">index</a><br>  
					<li><a href=\"C:\Knowledge\Computer_Program\Course_2024\semester_3\Web Programming 8238\Lab2\index.html\">Lab2</a><br>
					<li><a href=\"C:\Knowledge\Computer_Program\Course_2024\semester_3\Web Programming 8238\Lab3\Lab3_submit\index.html\">Lab3</a><br>
					<li><a href=\"C:\Knowledge\Computer_Program\Course_2024\semester_3\Web Programming 8238\lab4\index.html\">Lab4</a><br>
				</h2>
			</ul>
			</div>";
		?>