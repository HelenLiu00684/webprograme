<?php			
    echo "<div id=\"menu\">
			<ul>
				<h2>
					<li><a href=\"index.php?page=arrays\">Arrays</a><br>  
					<li><a href=\"index.php?page=objects\">Objects</a><br>  
				</h2>
			</ul>
			</div>";
		?>