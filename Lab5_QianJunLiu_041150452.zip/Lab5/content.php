<?php
    $firstName = "QianJun";
    $lastName = "Liu";
    $string1 = "Hello World!!";
    $string2 = "This is the first time I am using PHP!!";
    define("StudentID","041150452");
    function surface($radius, $height) {
        return number_format(2 * M_PI * $radius * $radius + 2 * M_PI * $radius * $height, 2);
    }
    function volumnArea($radius, $height) {
        return number_format(M_PI * $radius * $radius* $height,2);
    }
	echo "<div id=\"content\">";
	echo "My name is ".$firstName .$lastName."<br />";
	echo "My student number is ".StudentID."<br />";
	echo "The concatenated text is \"$string1 . $string2\"<br />";
	$text = $string1 . $string2;
	echo 'The length of the concatenated text "' . $text . '" is ' . strlen($text) . '<br />';
	$word = "PHP";
	$position = strpos($text, $word);
	echo "The position of word '" . $word . "' in the concatenated text '" . $text . "' is " . $position . ".<br>";
	$surfaceresult = surface(5, 8);
	echo "The surface area of the cylinder (with radius 5 cm and height 8 cm) is ".$surfaceresult.".<br>";
	$volumnresult = volumnArea(5, 8);
	echo "The volumn area of the cylinder (with radius 5 cm and height 8 cm) is ".$volumnresult.".<br>";
	echo "</div>";
?>