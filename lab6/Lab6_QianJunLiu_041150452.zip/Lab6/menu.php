<?php			
    echo "<div id=\"menu\">
			<ul>
				<h2>
					<li><a href=\"index.php\">index</a><br>  
					<li><a href='ChessBoard.php'>ChessBoard</a><br>
					<li><a href='Prime.php'>Prime</a></a><br>
					<li><a href='Pattern.php'>Pattern</a><br>
				</h2>
			</ul>
			</div>";
		?>